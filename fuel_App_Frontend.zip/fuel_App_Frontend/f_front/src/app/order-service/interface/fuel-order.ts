export interface FuelOrder {
    invoiceNumber: String;
    fuelType: number;
    fuelQuantity: number;
    id: number;
    gasStationName: String;
}
