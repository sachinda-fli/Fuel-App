export interface FuelReserves {
    fuelType: number;
    fuelQuantity: number;
}
