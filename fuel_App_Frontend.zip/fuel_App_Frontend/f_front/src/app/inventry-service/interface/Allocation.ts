export interface Allocation {
    invoiceNumber: String;
    fuelType: Number;
    fuelQuantity: Number;
    status: String;
}
