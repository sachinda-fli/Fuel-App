package com.fuel.fuelapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelApplicationTests {

    @Test
    void contextLoads() {
    }

}
