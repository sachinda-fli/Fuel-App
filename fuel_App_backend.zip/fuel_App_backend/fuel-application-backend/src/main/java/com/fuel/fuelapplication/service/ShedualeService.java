package com.fuel.fuelapplication.service;

import com.fuel.fuelapplication.model.Sheduale;

import java.util.List;

public interface ShedualeService {

    Sheduale save (Sheduale sheduale);
    List<Sheduale> getAllSheduale();

}
