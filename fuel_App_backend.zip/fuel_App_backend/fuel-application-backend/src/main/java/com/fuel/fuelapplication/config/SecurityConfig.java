package com.fuel.fuelapplication.config;

public class SecurityConfig {
}
