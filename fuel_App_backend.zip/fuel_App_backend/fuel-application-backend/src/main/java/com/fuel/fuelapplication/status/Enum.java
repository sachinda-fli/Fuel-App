package com.fuel.fuelapplication.status;

public class Enum {
    private String status;

}
